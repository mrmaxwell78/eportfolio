import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OptionsPanel extends CarPanel {

	private final double PACKAGE_A = 2200;
	private final double PACKAGE_B = 3250;
	private final double METALLIC = 650;
	private final double CASH_DISCOUNT = 750.00;
	
	private JRadioButton A;
	private JRadioButton B;
	private JRadioButton C;
	private ButtonGroup bg;
	private JCheckBox paint;
	private JCheckBox cash;
	
	private String selectedCar;
	private boolean validChoice;
	
	public OptionsPanel() {
		setLayout(new GridLayout(2,1));
		A = new JRadioButton("Package A: $2200");
		B = new JRadioButton("Package B: $3250");
		C = new JRadioButton("No Package");
		bg = new ButtonGroup();
		paint = new JCheckBox("Metallic Paint");
		cash = new JCheckBox("Paying by cash?");
		
		bg.add(A);
		bg.add(B);
		bg.add(C);
		
		A.addActionListener(new ErrorListener());
		B.addActionListener(new ErrorListener());
		C.addActionListener(new ErrorListener());
		carBox.addActionListener(new ErrorListener());
		
		setBorder(BorderFactory.createTitledBorder("Cars and Options"));
		
		add(A);
		add(B);
		add(C);
		add(paint);
		add(cash);
	}
	
	public double getOptionCost() {
		getCar();
		double optionCost = 0.0;
		if(selectedCar.equals("S40")) {
			if(A.isSelected()) {
				optionCost += PACKAGE_A;
			}
		}
		if(selectedCar.equals("S60")) {
			if(A.isSelected()) {
				optionCost += PACKAGE_A;
			}
		}
		if(selectedCar.equals("S70")) {
			if(A.isSelected()) {
				optionCost+=PACKAGE_A;
			}
			if(B.isSelected()) {
				optionCost+=PACKAGE_B;
			}
		}
		if(selectedCar.equals("S80")) {
			if(A.isSelected()) {
				optionCost+=PACKAGE_A;
			}
			if(B.isSelected()) {
				optionCost+=PACKAGE_B;
			}
		}
		
		if(paint.isSelected())
			optionCost += METALLIC;
		if(cash.isSelected())
			optionCost -= CASH_DISCOUNT;
		
		return optionCost;
	}
	
	public void getCar() {
		selectedCar = getSelectedCar();
	}
	
	private class ErrorListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			getCar();
			if (selectedCar.equals("S40: $27000") && B.isSelected()) {
				JOptionPane.showMessageDialog(null, "Package B is only Available on S70, and S80");
				validChoice = false;
			}
			else if (selectedCar.equals("S60: $32500") && B.isSelected()) {
				JOptionPane.showMessageDialog(null, "Package B is only Available on S70, and S80");
				validChoice = false;
			}
			else {
				validChoice = true;
			}
		}
	}
	
	public boolean isValid() {
		return validChoice;
	}
}