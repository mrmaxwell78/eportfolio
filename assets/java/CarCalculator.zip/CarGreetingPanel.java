import javax.swing.*;

public class CarGreetingPanel extends JPanel {
	private JLabel greeting;
	
	public CarGreetingPanel() {
		greeting = new JLabel("Welcome to Volvo");
		add(greeting);
	}

}
