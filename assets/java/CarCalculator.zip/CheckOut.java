import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CheckOut extends JFrame {
	
	protected JFrame checkout;
	protected JLabel message;
	protected JLabel messageAdr;
	protected JLabel messageCash;
	protected JLabel messageFinance;
	protected JMenuBar menuBar;
	protected JMenu fileMenu;
	protected JMenu textMenu;
	protected JMenuItem exitButton;
	protected JMenuItem resetButton;
	protected JRadioButtonMenuItem blueButton;//FIXME OR REMOVE
	protected JRadioButtonMenuItem blackButton;
	protected ButtonGroup bg;
	protected JButton reset;
	
	private final double TAX = 0.06;
	private final double TitleAndTags = 325.00;
	private final double financing = 0.07;
	private final int WIDTH = 600;
	private final int HEIGHT = 150;
	
	public String name;
	public String phone;
	public String address;
	public String account;
	

	
	public CheckOut(double sub, String Na, String Ph, String Adr, String ACN) {
		double total = 0;
	
		name = Na;
		phone = Ph;
		address = Adr;
		account = ACN;
		
		total += (sub * TAX) + sub;
		total += TitleAndTags;
		
		reset = new JButton("Start Over?");
		reset.addActionListener(new ResetListener());
		this.setLayout(new FlowLayout());
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			SwingUtilities.updateComponentTreeUI(this);
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Error setting the look and feel.");
			System.exit(0);
		}
		
		buildMenuBar();
		
		message = new JLabel("Hi " + name + " your total is $" + total + " which will be charged to your account #" + account + ".");
		
		messageAdr = new JLabel("We will give you a call at " +
		phone + " before delivery to your address of " + address + ".");
		messageFinance = new JLabel("And if you decide to finance over 12 months, your payments are $" + (total * financing) + ".");
		
		
		setTitle("Check Out");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(WIDTH, HEIGHT);
		
	
		add(message);
		add(messageFinance);
		add(messageAdr);
		add(reset, BorderLayout.SOUTH);
	
		
		setVisible(true);
		
	}
	
	private void buildMenuBar() {
		menuBar = new JMenuBar();
		buildFileMenu();
		buildTextMenu();
		menuBar.add(fileMenu);
		menuBar.add(textMenu);
		setJMenuBar(menuBar);
	}
	
	private void buildFileMenu() {
		exitButton = new JMenuItem("Exit");
		exitButton.setMnemonic(KeyEvent.VK_X);
		exitButton.addActionListener(new ExitButtonListener());
		resetButton = new JMenuItem("Start Over");
		resetButton.setMnemonic(KeyEvent.VK_S);
		resetButton.addActionListener(new ResetListener());
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		fileMenu.add(resetButton);
		fileMenu.add(exitButton);
	}
	
private void buildTextMenu() {
		
		blueButton = new JRadioButtonMenuItem("Blue");
		blueButton.setMnemonic(KeyEvent.VK_U);
		blueButton.addActionListener(new ColorButtonListener());
		
		blackButton = new JRadioButtonMenuItem("Black");
		blackButton.setMnemonic(KeyEvent.VK_L);
		blackButton.addActionListener(new ColorButtonListener());
		
		bg = new ButtonGroup();
		
		bg.add(blueButton);
		bg.add(blackButton);
		
		textMenu = new JMenu("Text");
		textMenu.setMnemonic(KeyEvent.VK_T);
		textMenu.add(blueButton);
		textMenu.add(blackButton);
		
	}

private class ExitButtonListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		try {
		ImageIcon icon = new ImageIcon("smilyface.png");
		JOptionPane.showMessageDialog(null, "Goodbye", "Goodbye", JOptionPane.INFORMATION_MESSAGE, icon);
		}
		catch(NullPointerException np) {
			
		}
		
		//Include image of smiley face as a pop up on exit
		System.exit(0);
		}
	}

private class ColorButtonListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		
			if(blackButton.isSelected()) {
				message.setForeground(Color.BLACK);
				messageFinance.setForeground(Color.BLACK);
				messageAdr.setForeground(Color.BLACK);
			}
			else if(blueButton.isSelected()) {
				message.setForeground(Color.BLUE);
				messageFinance.setForeground(Color.BLUE);
				messageAdr.setForeground(Color.BLUE);
			}
			
			repaint();
			
		}
	}

private class ResetListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		dispose();
		new CarGUI();
	}
}
}

