import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import java.io.File;
import java.io.IOException;


public class CarGUI extends JFrame {

	protected CarGreetingPanel greetings;
	protected OptionsPanel options;
	protected CustomerPanel customer;
	protected CarPanel car;
	protected JPanel buttonPanel;
	protected JButton calcButton;
	protected JMenuBar menuBar;
	protected JMenu fileMenu;
	protected JMenu textMenu;
	protected JMenuItem exitButton;
	protected JRadioButtonMenuItem cyanButton, greenButton, defaultButton;
	protected ButtonGroup bg;
	
	private final double TAX = 0.06;
	private final double TitleAndTags = 325.00;
	private final double financing = 0.07;
	private final double CASH_DISCOUNT = 750.00;
	private final int WIDTH = 1250;
	private final int HEIGHT = 200;
	
	
	public CarGUI() {
		
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			SwingUtilities.updateComponentTreeUI(this);
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Error setting the look and feel.");
			System.exit(0);
		}
		
		setTitle("Price Calculator");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		setSize(WIDTH, HEIGHT);

		greetings = new CarGreetingPanel();
		options = new OptionsPanel();
		customer = new CustomerPanel();
		car = new CarPanel();
	
		buildButtonPanel();
		buildMenuBar();
		
		add(greetings, BorderLayout.NORTH);
		add(options, BorderLayout.EAST);
		add(customer, BorderLayout.CENTER);
		//add(car, BorderLayout.WEST);
		add(buttonPanel, BorderLayout.SOUTH);
		
		setVisible(true);//This is to get rid of the default Java icon.
		setIconImage(Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("car.jpg")));
	}
	
	private void buildButtonPanel() {
		buttonPanel = new JPanel();
		calcButton = new JButton("Calculate");
		
		calcButton.addActionListener(new CalcButtonListener());
		calcButton.setMnemonic(KeyEvent.VK_C);
		buttonPanel.add(calcButton);
	
	}
	
	private void buildMenuBar() {
		menuBar = new JMenuBar();
		buildFileMenu();
		buildTextMenu();
		menuBar.add(fileMenu);
		menuBar.add(textMenu);//FIXME OR REMOVE
		setJMenuBar(menuBar);
	}
	
	private void buildFileMenu() {
		exitButton = new JMenuItem("Exit");
		exitButton.setMnemonic(KeyEvent.VK_X);
		exitButton.addActionListener(new ExitButtonListener());
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		fileMenu.add(exitButton);
	}
	/*FIXME OR REMOVE*/
	private void buildTextMenu() {
		
		cyanButton = new JRadioButtonMenuItem("Cyan");
		cyanButton.addActionListener(new ColorButtonListener());
		cyanButton.setMnemonic(KeyEvent.VK_N);
		greenButton = new JRadioButtonMenuItem("Green");
		greenButton.addActionListener(new ColorButtonListener());
		greenButton.setMnemonic(KeyEvent.VK_G);
		defaultButton = new JRadioButtonMenuItem("Default");
		defaultButton.addActionListener(new ColorButtonListener());
		defaultButton.setMnemonic(KeyEvent.VK_D);
		
		bg = new ButtonGroup();
		
		bg.add(cyanButton);
		bg.add(greenButton);
		bg.add(defaultButton);
		
		textMenu = new JMenu("Text");
		textMenu.setMnemonic(KeyEvent.VK_T);
		textMenu.add(cyanButton);
		textMenu.add(greenButton);
		textMenu.add(defaultButton);
		
	}
public void Calculate() {
	double subtotal;
	
	
	try {
		String soundName = "carstart.wav";
		AudioInputStream audioInputStream;
		audioInputStream = AudioSystem.getAudioInputStream(new File(soundName));
		Clip clip;
		clip = AudioSystem.getClip();
		clip.open(audioInputStream);
		clip.start();
	} catch (UnsupportedAudioFileException | IOException e1) {
		// TODO Auto-generated catch block
		System.out.println("File Not Found");
	} catch (LineUnavailableException e1) {
		// TODO Auto-generated catch block
		System.out.println("File Not Found");
	}

	String n, p, a, ac;
	
	
	n = customer.getName();
	p = customer.getPhone();
	a = customer.getAddress();
	
	
	//include sound file that goes vroom vroom on calcuate click
	ac = customer.getAccountNumber();
	
	subtotal = options.getCarCost() + options.getOptionCost();
	subtotal -= customer.getTradeCost();
	
	CheckOut c1 = new CheckOut(subtotal, n, p, a, ac);
	  
	  dispose();
}
	private class CalcButtonListener implements ActionListener{
		public void actionPerformed(ActionEvent e) {
			if(options.isValid() == true)
				Calculate();
			else
				JOptionPane.showMessageDialog(null, "You have selected an invalid package option.");
			  
		}
	}
	
	private class ExitButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				ImageIcon icon = new ImageIcon("smilyface.png");
				JOptionPane.showMessageDialog(null, "Goodbye", "Goodbye", JOptionPane.INFORMATION_MESSAGE, icon);
				}
				catch(NullPointerException np) {
					
				}
			System.exit(0);
		}
	}
	
	private class ColorButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(cyanButton.isSelected() == true)
				customer.setBackground(Color.CYAN);
			else if(greenButton.isSelected() == true)
				customer.setBackground(Color.GREEN);
			else
				customer.setBackground(null);
				
		}
	}

	public static void main(String[] args) {
		new CarGUI();
	}
}
