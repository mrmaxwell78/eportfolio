import javax.swing.*;
import java.awt.*;

public class CarPanel extends JPanel {
	
	public final double S40 = 27700;
	public final double S60 = 32500;
	public final double S70 = 36000;
	public final double S80 = 44000;
	
	protected JPanel innerPanel;
	protected String[] cars = {"S40: $27000", "S60: $32500", "S70: $36000", "S80: $44000"};
	protected JComboBox carBox;
	protected JLabel selectCar;
	
	/*protected JRadioButton s40;
	protected JRadioButton s60;
	protected JRadioButton s70;
	protected JRadioButton s80;
	protected ButtonGroup bg;*/
	
	public CarPanel() {
		//setLayout(new GridLayout(4,1));
		setLayout(new FlowLayout());
		innerPanel = new JPanel();
		innerPanel.setLayout(new FlowLayout());
		carBox = new JComboBox(cars);
		selectCar = new JLabel("Select Car:");
		
		/*s40 = new JRadioButton("S40: $27700", true);
		s60 = new JRadioButton("S60: $32500");
		s70 = new JRadioButton("S70: $36000");
		s80 = new JRadioButton("S80: $44000");
		
		bg = new ButtonGroup();
		bg.add(s40);
		bg.add(s60);
		bg.add(s70);
		bg.add(s80);*/
		
		innerPanel.add(selectCar);
		innerPanel.add(carBox);
		add(innerPanel);
		
		setBorder(BorderFactory.createTitledBorder("Car"));
		
		/*add(s40);
		add(s60);
		add(s70);
		add(s80);*/	
	}
	
	public String getSelectedCar() {
		return (String)carBox.getSelectedItem();
	}
	
	public double getCarCost() {
		double carCost = 0.0;
		
		/*if(s40.isSelected())
			carCost = S40;
		else if(s60.isSelected())
			carCost = S60;
		else if(s70.isSelected())
			carCost = S70;
		else
			carCost = S80;*/
		
		if (carBox.getSelectedIndex() == 0) {
			carCost = S40;
		}
		else if (carBox.getSelectedIndex() == 1) {
			carCost = S60;
		}
		else if (carBox.getSelectedIndex() == 2) {
			carCost = S70;
		}
		else {
			carCost = S80;
		}
		
		return carCost;
	}
}