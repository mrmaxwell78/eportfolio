import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class CustomerPanel extends JPanel {
	
	Random rand = new Random();
	protected JLabel Name, Phone, Address, accNumber;
	protected JTextField name;
	protected JTextField phone;
	protected JTextField address;
	protected JLabel tradeIn;
	protected JTextField tradeText;
	protected int accountNumber = rand.nextInt(9000) + 1000;
	protected String accNumberS = Integer.toString(accountNumber);
	
	public String fullName;
	public String phoneNumber;
	public String Addr;
	public double tradeInCost = 0;
	
	public CustomerPanel() {
		setLayout(new GridLayout(4,2));
		Name = new JLabel("Name: ");
		Phone = new JLabel("Phone: ");
		Address = new JLabel("Address: ");
		accNumber = new JLabel("Account Number: " + accNumberS);
		name = new JTextField(30);
		phone = new JTextField(12);
		address = new JTextField(50);
		tradeIn = new JLabel("Please enter the value of your old car if trading in.");
		tradeText = new JTextField(10);
		
		
		add(Name);
		add(Phone);
		add(Address);
		add(name);
		add(phone);
		add(address);
		add(accNumber);
		add(tradeIn);
		add(tradeText);
	}
	
	public String getName() {
		if(fullName == null)
			setName();
		else if (name.getText() != fullName)
			setName();
		setName();
		return fullName;
		
	}
	
	public String getPhone() {
		if(phoneNumber == null)
			setPhone();
		else if(phone.getText() != phoneNumber)
			setPhone();
		return phoneNumber;
	}
	
	public String getAddress() {
		if(Addr == null)
			setAddress();
		else if(address.getText() != Addr)
			setAddress();
		
		return Addr;
	}
	
	public String getAccountNumber() {
		return accNumberS;
	}
	
	public void setName() {
		fullName = name.getText();
	}
	
	public void setPhone() {
		phoneNumber = phone.getText();
	}
	
	public void setAddress() {
		Addr = address.getText();
	}
	public double getTradeCost() {
		if(tradeInCost == 0)//intialized to 0 so it is forced to set input
			setTradeCost();
		else if(Double.parseDouble(tradeText.getText()) != tradeInCost)
			setTradeCost();
		return tradeInCost;
	}
		public void setTradeCost() {
			try { //Try catch incase nothing is entered
			tradeInCost = Double.parseDouble(tradeText.getText());

			}
			catch(NumberFormatException n) {
			//nothing here so it catches the exception
			}
		}
}
